﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

namespace WikiApplication
{
    public partial class WikiApplication : Form
    {
        public WikiApplication()
        {
            InitializeComponent();
        }

        int selItem;
        int currentItem = 0;
        string currentFile;
        string newFileName;
        //string[,] wikiArray2D = new string[12, 4];

        string[,] wikiArray2D = {   {"Test 0 Name","Test 0 Category","Test 0 Structure","Test 0 Definition"}, {"Test 1 Name","Test 1 Category","Test 1 Structure","Test 1 Definition"},
                                    {"Test 2 Name","Test 2 Category","Test 2 Structure","Test 2 Definition"}, {"Test 3 Name","Test 3 Category","Test 3 Structure","Test 3 Definition"},
                                    {"Test Namea","Test Category","Test Structure","Test Definition"}, {"Test Nameb","Test Category","Test Structure","Test Definition"},
                                    {"Test Namec","Test Category","Test Structure","Test Definition"}, {"Test Named","Test Category","Test Structure","Test Definition"},
                                    {"Test Namee","Test Category","Test Structure","Test Definition"}, {"Test Namef","Test Category","Test Structure","Test Definition"},
                                    {"Test Nameg","Test Category","Test Structure","Test Definition"}, {"","","",""}  };

        // Displays listData in list box
        private void DisplayList()
        {
            ListBoxItems.Items.Clear();
            SortArray();

            for (int i = 0; i < wikiArray2D.GetLength(0); i++)
            {
                ListBoxItems.Items.Add(String.Format("{0, -10} {1, 70}", wikiArray2D[i, 0],  wikiArray2D[i, 1]));
            }
        }

        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            bool loopBool = false;
            while (!loopBool)
            {
                if (currentItem >= 12) {
                    currentItem = 0;
                    break;
                }

                if (wikiArray2D[currentItem, 0] == "")
                {
                    wikiArray2D[currentItem, 0] = TextBoxName.Text;
                    wikiArray2D[currentItem, 1] = TextBoxCategory.Text;
                    wikiArray2D[currentItem, 2] = TextBoxStructure.Text;
                    wikiArray2D[currentItem, 3] = TextBoxDefinition.Text;

                    DisplayList();
                    loopBool = true;
                }
                currentItem++;
            }
            currentItem = 0;
        }

        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            if (ListBoxItems.SelectedIndex >= 0)
            {
                selItem = ListBoxItems.SelectedIndex;

                wikiArray2D[selItem, 0] = TextBoxName.Text;
                wikiArray2D[selItem, 1] = TextBoxCategory.Text;
                wikiArray2D[selItem, 2] = TextBoxStructure.Text;
                wikiArray2D[selItem, 3] = TextBoxDefinition.Text;

                DisplayList();
            }
        }

        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            if (ListBoxItems.SelectedIndex >= 0)
            { 
                selItem = ListBoxItems.SelectedIndex;
                wikiArray2D[selItem, 0] = "";
                wikiArray2D[selItem, 1] = "";
                wikiArray2D[selItem, 2] = "";
                wikiArray2D[selItem, 3] = "";

                DisplayList();
            }
        }

        private void ButtonSearch_Click(object sender, EventArgs e)
        {
            bool found = false;
            int index = 0;
            for (int i = 0; i < 12; i++)
            {
                if (wikiArray2D[i, 0] == TextBoxSearch.Text)
                {
                   StatusStrip.Text = "Search for " + TextBoxSearch.Text + " found at index " + i;
                    found = true;
                    break;
                }
            }
            if (!found)
            {
                StatusStrip.Text = "Search for " + TextBoxSearch.Text + " finished without finding any instances!";
                TextBoxSearch.Text = "";
                ActiveControl = TextBoxSearch;
            }
        }

        private void ButtonOpen_Click(object sender, EventArgs e)
        {
            DisplayList();

            //int ptr = 0;
            //try
            //{
            //    using (Stream stream = File.Open("wikiArray2D.bin", FileMode.Open))
            //    {
            //        BinaryFormatter bin = new BinaryFormatter();
            //        while (stream.Position < stream.Length)
            //        {
                        //wikiArray2D[ptr] = (RCModel)bin.Deserialize(stream);
            ///           ptr++;
            //        }
            //    }
            //}
            //catch (IOException ex)
            //{ 
                
            //}
        }

        // method to save list for later use
        // includes status strips with outcome information
        private void ButtonSave_Click(object sender, EventArgs e)
        {
            {
                Stream stream;
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.Filter = "txt files (*.txt)|*.txt";
                saveFileDialog.Title = "Save Wiki Information";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    if ((stream = saveFileDialog.OpenFile()) != null)
                    {
                        stream.Close();
                        //File.WriteAllLines(saveFileDialog.FileName, wikiArray2D[,]);
                        StatusStrip1.Text = "File Saved!";
                    }
                }
            }
        }

        private void SortArray() 
        {
            int arrLen = wikiArray2D.GetLength(0);
            string[] temp = new string[4];
            for (int i = 0; i < arrLen-1; i++)
            {
                for (int j = i + 1; j < arrLen; j++)
                {
                    if (String.Compare(wikiArray2D[i, 0], wikiArray2D[j, 0]) > 0)
                    {
                        temp[0] = wikiArray2D[i, 0];
                        temp[1] = wikiArray2D[i, 1];
                        temp[2] = wikiArray2D[i, 2];
                        temp[3] = wikiArray2D[i, 3];
                        wikiArray2D[i, 0] = wikiArray2D[j, 0];
                        wikiArray2D[i, 1] = wikiArray2D[j, 1];
                        wikiArray2D[i, 2] = wikiArray2D[j, 2];
                        wikiArray2D[i, 3] = wikiArray2D[j, 3];
                        wikiArray2D[j, 0] = temp[0];
                        wikiArray2D[j, 1] = temp[1];
                        wikiArray2D[j, 2] = temp[2];
                        wikiArray2D[j, 3] = temp[3];
                    }
                }
            }
        }

        private void ListBoxItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            selItem = ListBoxItems.SelectedIndex;

            TextBoxName.Text = wikiArray2D[selItem, 0];
            TextBoxCategory.Text = wikiArray2D[selItem, 1];
            TextBoxStructure.Text = wikiArray2D[selItem, 2];
            TextBoxDefinition.Text = wikiArray2D[selItem, 3];
        }
    }
}
