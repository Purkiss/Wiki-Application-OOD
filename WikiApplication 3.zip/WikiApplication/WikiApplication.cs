﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

// Zac Purkiss (P444025)
// 15/03/2022
// Assignment 1 - Wiki Application
// Make application to store and retrieve wiki information

namespace WikiApplication
{
    public partial class WikiApplication : Form
    {
        public WikiApplication()
        {
            InitializeComponent();
        }

        String blankChar = "ㅤ";
        int selItem;
        int currentItem = 0;
        // string currentFile;
        // string newFileName;
        int arrCol = 12, arrLen = 4;

        // creating array and a default array that is set if no file is opened
        string[,] wikiArray2D = new string[12, 4];

        string[,] wikiArray2DDefault = {   {"Array","Array","Linear","An array is a type of data structure that stores a fixed number of elements into a collection of the same data type"}, {"2D Array","Array","Linear","A two dimensional array is an array that stores data into both rows and columns, these are then referenced using both horizontal and vertical numbers"},
                                    {"List","List","Linear","A list is a data type that stores a number of ordered values into a single row of values, which can be referenced in the same way as an array"}, {"Linked List","List","Linear","A linked list is a data structure in which a node contains both an element as well as a link to the next node, creating a list of nodes"},
                                    {"Self-Balance Tree","Tree","Non-Linear","A self balancing tree is a type of binary search tree that uses nodes to automatically keep its height, this keeps it very small"}, {"Heap","Tree","Non-Linear","A heap is a type of tree that satisfies the heap property"},
                                    {"Binary Search Tree","Tree","Non-Linear","A binary search tree is a sorted tree that stores information in succeeding order from left to right, where the left side of a given branch is smaller than the right, and the right is bigger than the left"}, {"Graph","Graphs","Non-Linear","A graph is a data structure that uses nodes and edges to solve problems"},
                                    {"Set","Abstract","Non-Linear","A set stores unique values without any specific order. This is an abstract data type"}, {"Queue","Abstract","Linear","A queue is a collection that stores several values where new values go to the back and values that are requested come from the front of the line. Similar to queueing in a shop the first value to enter the queue will be the first to come out"},
                                    {"Stack","Abstract","Linear","A stack is similar to a queue however the latest item put into the stack is the first to come out, eg. If you have a stack of cans in a shop you take the top can off first"}, {"Hash Table","Hash","Non-Linear","A hash table is used to associate specific values or strings to an index in a table"}  };

        // Displays listData in list box
        private void DisplayList()
        {
            ListBoxItems.Items.Clear();
            SortArray();

            for (int i = 0; i < wikiArray2D.GetLength(0); i++)
            {
                //if (wikiArray2D[i, 0] != "~")
                if (wikiArray2D[i, 0] != "ㅤ" && wikiArray2D[i, 0].Length > 20)
                {
                    wikiArray2D[i, 0].Substring(0, 5);
                    wikiArray2D[i, 0].PadRight(5);
                }

                ListBoxItems.Items.Add(String.Format("{0}\t\t\t\t{1}", wikiArray2D[i, 0],  wikiArray2D[i, 1]));
            }
        }

        private void ButtonAdd_Click(object sender, EventArgs e)
        {
            bool loopBool = false;
            while (!loopBool)
            {
                if (currentItem >= 12) {
                    currentItem = 0;
                    StatusStrip.Text = "Item failed to add, too many entries!";
                    break;
                }

                if (wikiArray2D[currentItem, 0] == "ㅤ")
                {
                    wikiArray2D[currentItem, 0] = TextBoxName.Text;
                    wikiArray2D[currentItem, 1] = TextBoxCategory.Text;
                    wikiArray2D[currentItem, 2] = TextBoxStructure.Text;
                    wikiArray2D[currentItem, 3] = TextBoxDefinition.Text;

                    DisplayList();

                    StatusStrip.Text = "Item added successfully!";
                    loopBool = true;
                }
                currentItem++;
            }
            currentItem = 0;
        }

        private void ButtonEdit_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(TextBoxName.Text))
            {
                if (!String.IsNullOrEmpty(TextBoxCategory.Text))
                {
                    if (ListBoxItems.SelectedIndex >= 0 && ListBoxItems.SelectedIndex <= 11)
                    {
                        selItem = ListBoxItems.SelectedIndex;

                        wikiArray2D[selItem, 0] = TextBoxName.Text;
                        wikiArray2D[selItem, 1] = TextBoxCategory.Text;
                        wikiArray2D[selItem, 2] = TextBoxStructure.Text;
                        wikiArray2D[selItem, 3] = TextBoxDefinition.Text;

                        StatusStrip.Text = "Item edited!";
                        DisplayList();
                    }
                }
                else
                    StatusStrip.Text = "Failed to edit due to blank category!";
            }
            else
                StatusStrip.Text = "Failed to edit due to blank name!";
        }

        private void ButtonDelete_Click(object sender, EventArgs e)
        {
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;

            DialogResult result = MessageBox.Show("Do you want to delete?", "Delete?", buttons);

            if (result == DialogResult.Yes)
            {
                if (ListBoxItems.SelectedIndex >= 0 && ListBoxItems.SelectedIndex<=11)
                {
                    selItem = ListBoxItems.SelectedIndex;
                    wikiArray2D[selItem, 0] = blankChar;
                    wikiArray2D[selItem, 1] = blankChar;
                    wikiArray2D[selItem, 2] = blankChar;
                    wikiArray2D[selItem, 3] = blankChar;

                    DisplayList();

                    StatusStrip.Text = "Successully deleted!";
                }
            }
            else
            {
                StatusStrip.Text = "Delete failed!";
            }
        }

        private void ButtonSearch_Click(object sender, EventArgs e)
        {
            bool found = false;
            // int index = 0;
            for (int i = 0; i < 12; i++)
            {
                if (wikiArray2D[i, 0] == TextBoxSearch.Text)
                {
                    StatusStrip.Text = "Search for " + TextBoxSearch.Text + " found at index " + i;
                    found = true;
                    ListBoxItems.SetSelected(i, true);
                    break;
                }
            }
            if (!found)
            {
                StatusStrip.Text = "Search for " + TextBoxSearch.Text + " finished without finding any instances!";
                TextBoxSearch.Text = "";
                ActiveControl = TextBoxSearch;
            }
        }

        private void ButtonOpen_Click(object sender, EventArgs e)
        {
            //DisplayList();

            //int ptr = 0;
            //try
            //{
            //    using (Stream stream = File.Open("wikiArray2D.bin", FileMode.Open))
            //    {
            //        BinaryFormatter bin = new BinaryFormatter();
            //        while (stream.Position < stream.Length)
            //        {
            //            wikiArray2D[ptr] = (RCModel)bin.Deserialize(stream);
            ///           ptr++;
            //        }
            //    }
            //}
            //catch (IOException ex)
            //{ 

            //}

            var filePath = string.Empty;

            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "data");
                openFileDialog.Filter = "bin files (*.bin)|*.bin";
                openFileDialog.FilterIndex = 2;
                openFileDialog.RestoreDirectory = true;

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (Stream stream = File.Open(openFileDialog.FileName, FileMode.Open))
                        {
                            BinaryFormatter bin = new BinaryFormatter();
                            for (int i = 0; i < arrCol; i++)
                            {
                                for (int j = 0; j < arrLen; j++)
                                {
                                    wikiArray2D[i, j] = (string)bin.Deserialize(stream);
                                }
                            }
                        }
                        StatusStrip.Text = "File successfully opened!";
                    }
                    catch (IOException ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                }
                else 
                {
                    wikiArray2D = wikiArray2DDefault;
                    StatusStrip.Text = "File failed to open, opening default list!";
                }
            }
            DisplayList();
        }

        // method to save list for later use
        // includes status strips with outcome information
        private void ButtonSave_Click(object sender, EventArgs e)
        {
            // Stream stream;
            // SaveFileDialog saveFileDialog = new SaveFileDialog();
            // saveFileDialog.Filter = "txt files (*.txt)|*.txt";
            // saveFileDialog.Title = "Save Wiki Information";

            // if (saveFileDialog.ShowDialog() == DialogResult.OK)
            // {
            // if ((stream = saveFileDialog.OpenFile()) != null)
            // {
            // stream.Close();
            // File.WriteAllLines(saveFileDialog.FileName, wikiArray2D[,]);
            //StatusStrip1.Text = "File Saved!";
            //}
            //}

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "bin files (*.bin)|*.bin";
            saveFileDialog.Title = "Save Wiki Data";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (Stream stream = File.Open(saveFileDialog.FileName, FileMode.Create))
                    {
                        BinaryFormatter bin = new BinaryFormatter();
                        for (int i = 0; i < arrCol; i++)
                        {
                            for (int j = 0; j < arrLen; j++)
                            {
                                bin.Serialize(stream, wikiArray2D[i, j]);
                            }
                        }
                    }
                    StatusStrip.Text = "Saved successfully!";
                }
                catch (IOException ex)
                {
                    MessageBox.Show(ex.ToString());
                    StatusStrip.Text = "Save failed!";
                }
            }
        }

        private void SortArray() 
        {
            int arrLen = wikiArray2D.GetLength(0);
            string[] temp = new string[4];
            for (int i = 0; i < arrLen-1; i++)
            {
                for (int j = i + 1; j < arrLen; j++)
                {
                    if(String.Compare(wikiArray2D[i, 0], wikiArray2D[j, 0]) > 0)
                    {
                        temp[0] = wikiArray2D[i, 0];
                        temp[1] = wikiArray2D[i, 1];
                        temp[2] = wikiArray2D[i, 2];
                        temp[3] = wikiArray2D[i, 3];
                        wikiArray2D[i, 0] = wikiArray2D[j, 0];
                        wikiArray2D[i, 1] = wikiArray2D[j, 1];
                        wikiArray2D[i, 2] = wikiArray2D[j, 2];
                        wikiArray2D[i, 3] = wikiArray2D[j, 3];
                        wikiArray2D[j, 0] = temp[0];
                        wikiArray2D[j, 1] = temp[1];
                        wikiArray2D[j, 2] = temp[2];
                        wikiArray2D[j, 3] = temp[3];
                    }
                }
            }
        }

        private void TextBoxSearch_DoubleClick(object sender, EventArgs e)
        {
            TextBoxSearch.Text = "";
            StatusStrip.Text = "Search box cleared!";
        }

        // This doesn't exist dw bout it <3
        private void TextBoxName_Click(object sender, EventArgs e)
        {
            blankCharBoxClear();
        }

        private void TextBoxCategory_Click(object sender, EventArgs e)
        {
            blankCharBoxClear();
        }

        private void TextBoxStructure_Click(object sender, EventArgs e)
        {
            blankCharBoxClear();
        }

        private void TextBoxDefinition_Click(object sender, EventArgs e)
        {
            blankCharBoxClear();
        }

        private void blankCharBoxClear()
        {
            if (String.Equals(TextBoxName.Text, blankChar))
            {
                TextBoxName.Text = "";
            }
            if (String.Equals(TextBoxCategory.Text, blankChar))
            {
                TextBoxCategory.Text = "";
            }
            if (String.Equals(TextBoxStructure.Text, blankChar))
            {
                TextBoxStructure.Text = "";
            }
            if (String.Equals(TextBoxDefinition.Text, blankChar))
            {
                TextBoxDefinition.Text = "";
            }
        }

        private void ListBoxItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                selItem = ListBoxItems.SelectedIndex;

                TextBoxName.Text = wikiArray2D[selItem, 0];
                TextBoxCategory.Text = wikiArray2D[selItem, 1];
                TextBoxStructure.Text = wikiArray2D[selItem, 2];
                TextBoxDefinition.Text = wikiArray2D[selItem, 3];
            }
            catch
            {
                StatusStrip.Text = "Invalid entry selected!";
            }
        }
    }
}
